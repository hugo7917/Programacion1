#Ejercicio 2

var_1=float(input("introduce el primer numero: "))
var_2=float(input("introduce el segundo numero: "))
var_total= (var_1 + var_2)
var_total_entre3= ((var_1+var_2)/3)
print(f"el resultado de sumar {var_1} y {var_2} es:", var_total)
print(f"el resultado de dividir {var_total} entre {3} es:", round(var_total_entre3,3))

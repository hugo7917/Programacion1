#ejercicio 4

var_1= int(input("dame un valor: "))
var_2= int(input("dame otro valor: "))
var_porcentage=(var_1%var_2)
var_potencia= (var_1**var_2)
var_divisionentera= (var_1//var_2)
print("el resultado de la división entera de {var_1} a {var_2} es:", var_divisionentera)
print("el resultado de elevar {var_1} a {var_2} es:", var_potencia)
print(f"el resultado del resto de {var_1} y {var_2} es:", var_porcentage)



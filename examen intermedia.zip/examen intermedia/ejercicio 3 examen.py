#ejercicio 3

import math
var_sqrt= math.sqrt
var_1= int(input("dime el valor de una lado de un triangulo equilatero: "))
var_area= (((var_sqrt(3))/4)*(var_1**2))
print("el area del triangulo equilatero es: ",round(var_area,2))

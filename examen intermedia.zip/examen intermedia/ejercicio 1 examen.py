#ejercicio 1

var_1=float(input("introduce el primer numero: "))
var_2=float(input("introduce el segundo numero: "))
var_total= (var_1 + var_2)
print(f"el resultado de sumar {var_1} y {var_2} es:", var_total)

#1. En var 1 y var 2 no tienen al principio de la frase "float".
#2. El var total se tenia que escribir con el guión bajo "var_total".
#3. En el print, la f esta separada del resto con una coma y no lo tiene que estar.
#4. A l final del print pone total en vez de "var_total.

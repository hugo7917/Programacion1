
# 33. Programa un código que permita contar el número de vocales de la siguiente frase: No hay mal que dure cien años

var_txt="No hay mal que dure cien años"

var_1=var_txt.count("a")
var_2=var_txt.count("e")
var_3=var_txt.count("i")
var_4=var_txt.count("o")
var_5=var_txt.count("u")

print(f"el numero de a es {var_1},el numero de e es {var_2},el numero de i es {var_3},el numero de o es {var_4},el numero de u es {var_5}")




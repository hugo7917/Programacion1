#29. Busca Internet qué función permite obtener la longitud de un String, realiza un programa que al introducir una frase devuelva la longitud.


var_1= input("dime una frase: ")

print(len(var_1))





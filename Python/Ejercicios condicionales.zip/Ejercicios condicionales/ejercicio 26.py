
#26. Realiza un programa que, al introducir una letra por teclado, aparezca por pantalla si está o no en mayúscula. Utiliza dos IF’s que establezcan True o False a la condición.

var_1= (input("dime una letra: "))

if var_1.islower()== True: 
    print("el valor es minuscula")

elif var_1.isupper()== True:
    print("el valor es mayuscula")

else:
    print("la letra es mayuscula ¿?")







# 19: Programa que introduzca dos numero y devuelva cual de los dos es mayor, menor o son iguales.


var_1=int(input("introduce un numero: "))
var_2=int(input("introduce otro numero: "))

if var_1>var_2:
    print("El numero",var_1," es mayor que" ,var_2,)
    
if var_1<var_2:
    print("El numero",var_2," es mayor que" ,var_1,)

if var_1==var_2:
    print("El numero",var_1," es igual que" ,var_2,)





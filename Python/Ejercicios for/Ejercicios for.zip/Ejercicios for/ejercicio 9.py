
#43. Realiza un programa que recorra con un for una palabra introducida por teclado y se imprima por pantalla cada letra.

var_palabra = input("Introduce una palabra: ")
for posición in range(len(var_palabra)):
    print(f"En la posición {posición} está la {var_palabra[posición]}")










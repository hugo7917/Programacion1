
#42. Imprima el siguiente patrón con el ciclo for.
var_sec="*****"
for contador in range(len(var_sec)):
    contador+=1
    print(var_sec[0:contador])

for contador in range(len(var_sec)):
    var_sec_2=var_sec[1:]
    print(var_sec_2)
    var_sec=var_sec_2









#35. Programa que al introducir un número por teclado permita mostrar ese número de veces tu nombre

var_nombre="Hugo Carballas Gómez"
var_numero=int(input("introduce el numero de veces que quieras que se repita tu numero: "))
for contador in range (var_numero):
    print(var_nombre)

        










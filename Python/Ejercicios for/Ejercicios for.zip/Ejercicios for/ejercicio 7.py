
#41. Imprime el siguiente patrón utilizando for:

for i in range(5, 0, -1):
    for var_vuelta in range(i, 0, -1):
        print(var_vuelta, end=" ")
    print()  


















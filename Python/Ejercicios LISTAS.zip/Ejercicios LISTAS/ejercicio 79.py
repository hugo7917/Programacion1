#79. A través de la variable definida var1="a,b,1,r,sal,34,mar”. Pasa estos valores a una lista y haz que presente por pantalla cantidad de valores almacenada. Utiliza el método que corresponde. Máximo 3 líneas de código

var1 = "a,b,1,r,sal,34,mar"
lista = var1.split(",")
print("Cantidad de valores:", len(lista))


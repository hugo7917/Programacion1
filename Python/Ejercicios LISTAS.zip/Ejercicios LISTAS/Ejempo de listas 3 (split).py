#Ejempo de listas 3 (split)

frase= input("Introduce una frase: ")

lista[]

lista=frase.split()

palabra=input("Introduce una palabra: ")

print(lista)
print(lista.count(palabra))








#1

numero= []
list1= input("introduce 6 numeros separados por guinoes: ")
 
for i in (numero):
    numero=lista1.split("-")
    print=numero
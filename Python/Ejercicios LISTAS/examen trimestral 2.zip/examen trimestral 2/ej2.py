#2

orden_frase=[]
list_palabras= input("Escribe una frase separadas por un guión: ")
orden_frase= list_palabras.split("-")

print= orden_frase












